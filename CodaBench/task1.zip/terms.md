<h1>Terms and Conditions</h1>
<ul>
    <li>By participating in this task, you agree to the terms and conditions set forth by the AraSentEval 2026 organizers.</li>
    <li>The data provided is for research purposes only.</li>
    <li>Participants must submit a system description paper to be ranked in the official leaderboard.</li>
</ul>