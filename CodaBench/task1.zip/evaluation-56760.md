<h1>Evaluation</h1>
<p>Systems will be evaluated using standard classification metrics.</p>
<ul>
    <li><strong>Primary Metric</strong>: Macro F1-Score, to account for any potential class imbalance.</li>
    <li><strong>Secondary Metrics</strong>: Overall accuracy, as well as precision, recall, and F1-score for each class.</li>
</ul>